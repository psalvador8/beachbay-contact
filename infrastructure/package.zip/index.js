// lambda/index.js
const AWS = require("aws-sdk");

const ddb = new AWS.DynamoDB.DocumentClient({ region: process.env.REGION });
const comprehend = new AWS.Comprehend({ region: process.env.REGION });
const translate = new AWS.Translate({ region: process.env.REGION });
const ses = new AWS.SES({ region: process.env.REGION });

const TABLE = process.env.DYNAMO_TABLE;
const SENDER = process.env.SENDER_EMAIL;
const NOTIFY = process.env.NOTIFY_EMAIL;

// helper to build HTTP response for API GW v2 (Lambda proxy)
function response(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
}

exports.handler = async (event) => {
  try {
    // API Gateway v2 sends body as string
    const body = (event.body && typeof event.body === "string") ? JSON.parse(event.body) : (event.body || {});

    const name = (body.name || "").trim();
    const email = (body.email || "").trim();
    const message = (body.message || "").trim();

    if (!name || !email || !message) {
      return response(400, { error: "name, email and message are required" });
    }

    // create a unique id
    const inquiry_id = (typeof crypto !== "undefined" && crypto.randomUUID) ? crypto.randomUUID() : (Date.now().toString(36) + Math.random().toString(36).slice(2));

    // Detect dominant language first
    let langCode = "en";
    try {
      const langRes = await comprehend.detectDominantLanguage({ Text: message }).promise();
      if (langRes && langRes.Languages && langRes.Languages.length > 0) {
        langCode = langRes.Languages[0].LanguageCode || "en";
      }
    } catch (err) {
      console.warn("Comprehend detectDominantLanguage failed:", err.message || err);
    }

    // Optionally translate to English for sentiment analysis if not English
    let messageForAnalysis = message;
    if (langCode !== "en") {
      try {
        const tr = await translate.translateText({
          SourceLanguageCode: langCode,
          TargetLanguageCode: "en",
          Text: message
        }).promise();
        if (tr && tr.TranslatedText) messageForAnalysis = tr.TranslatedText;
      } catch (err) {
        console.warn("Translate failed:", err.message || err);
      }
    }

    // Detect sentiment on the message (in English or original)
    let sentiment = "NEUTRAL";
    try {
      const s = await comprehend.detectSentiment({
        Text: messageForAnalysis,
        LanguageCode: "en"
      }).promise();
      sentiment = s.Sentiment || "NEUTRAL";
    } catch (err) {
      console.warn("Comprehend detectSentiment failed:", err.message || err);
    }

    // Persist to DynamoDB
    const item = {
      inquiry_id,
      name,
      email,
      message,
      language: langCode,
      sentiment,
      created_at: new Date().toISOString(),
      status: "new"
    };

    await ddb.put({
      TableName: TABLE,
      Item: item
    }).promise();

    // Prepare email content
    const subjectToGuest = `BeachBay Hotel – Inquiry received (${inquiry_id})`;
    const bodyToGuest = `
      <p>Hi ${name},</p>
      <p>Thanks for contacting BeachBay Hotel. We received your message and will reply shortly.</p>
      <p><strong>Your reference:</strong> ${inquiry_id}</p>
      <hr />
      <p>Your message:</p>
      <p>${message}</p>
      <p>— BeachBay Guest Services</p>
    `;

    const subjectToStaff = `New inquiry ${inquiry_id} — ${sentiment}`;
    const bodyToStaff = `
      <p>New inquiry received:</p>
      <ul>
        <li><strong>ID:</strong> ${inquiry_id}</li>
        <li><strong>Name:</strong> ${name}</li>
        <li><strong>Email:</strong> ${email}</li>
        <li><strong>Language:</strong> ${langCode}</li>
        <li><strong>Sentiment:</strong> ${sentiment}</li>
        <li><strong>Received:</strong> ${item.created_at}</li>
      </ul>
      <p>Message:</p>
      <p>${message}</p>
    `;

    // Send confirmation to guest
    try {
      await ses.sendEmail({
        Source: SENDER,
        Destination: { ToAddresses: [email] },
        Message: {
          Subject: { Data: subjectToGuest },
          Body: {
            Html: { Data: bodyToGuest },
            Text: { Data: `Thanks for contacting BeachBay Hotel. Reference: ${inquiry_id}\n\nYour message:\n${message}` }
          }
        }
      }).promise();
    } catch (err) {
      console.warn("SES send to guest failed:", err.message || err);
      // fall through — we don't fail the whole request due to email failure
    }

    // Send notification to staff
    try {
      await ses.sendEmail({
        Source: SENDER,
        Destination: { ToAddresses: [NOTIFY] },
        Message: {
          Subject: { Data: subjectToStaff },
          Body: {
            Html: { Data: bodyToStaff },
            Text: { Data: `New inquiry ${inquiry_id} from ${name} <${email}>. Sentiment: ${sentiment}` }
          }
        }
      }).promise();
    } catch (err) {
      console.warn("SES send to staff failed:", err.message || err);
    }

    return response(200, { success: true, inquiry_id });
  } catch (err) {
    console.error("Handler error:", err);
    return response(500, { error: "Internal server error" });
  }
};
